<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\EncargadoController;
use App\Http\Controllers\TipoTransporteController;
use App\Http\Controllers\RutaController;
use App\Http\Controllers\ProveedorController;
use App\Http\Controllers\ComessaController;


/*
|---------------------------------------------------------------------------
| API Routes
|---------------------------------------------------------------------------
|
| Aquí es donde puedes registrar rutas de API para tu aplicación.
| Estas rutas son cargadas por el RouteServiceProvider y todas
| ellas se asignarán al grupo de middleware "api". ¡Haz algo genial!
|
*/

// Rutas públicas
Route::post('login', [AuthController::class, 'login']);  // Login para obtener el token
Route::post('register', [AuthController::class, 'register']); // Registro de usuario (si lo necesitas)

// Rutas protegidas por JWT
Route::middleware('auth:api')->group(function () {
    // Rutas para obtener la información del usuario autenticado
    Route::get('me', [AuthController::class, 'me']);
    
    // Ruta para cerrar sesión (revocar el token)
    Route::post('logout', [AuthController::class, 'logout']);
    Route::resource('proveedores', ProveedorController::class);
    Route::resource('clientes', ClienteController::class);
    Route::resource('encargados', EncargadoController::class);
    Route::resource('tipos-transporte', TipoTransporteController::class);
    Route::resource('rutas', RutaController::class);
    Route::resource('comessa', ComessaController::class);


    
});
    