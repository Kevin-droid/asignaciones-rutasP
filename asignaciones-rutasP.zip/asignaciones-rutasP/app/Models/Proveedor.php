<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Ramsey\Uuid\Guid\Guid;
use Ramsey\Uuid\Guid\GuidInterface;

class Proveedor extends Model
{
    use HasFactory;

    // Indica que el campo 'id' es un UUID
    protected $primaryKey = 'id_proveedor';

    // Campos que se pueden asignar masivamente
    protected $fillable = [
        'id_proveedor',
        'nombre',
        'direccion',
        'telefono'
        // Agrega los demás campos según la estructura de tu tabla
    ];

    // Si es necesario, define las relaciones, mutadores, etc.
    // Relación con Ruta
  
    // Relación con las rutas donde el proveedor es el remitente
    public function rutasRemitente()
    {
        return $this->hasMany(Ruta::class, 'remitente', 'id_proveedor');
    }

    // Relación con las rutas donde el proveedor es el encargado de la entrega
    public function rutasEntrega()
    {
        return $this->hasMany(Ruta::class, 'entrega', 'id_proveedor');
    }
   
}
