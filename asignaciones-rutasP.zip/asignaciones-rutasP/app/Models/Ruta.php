<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Ramsey\Uuid\Guid\Guid;
use Ramsey\Uuid\Guid\GuidInterface;

class Ruta extends Model
{
    use HasFactory;

    // Definir la tabla asociada
    protected $table = 'ruta';
    
    // Indica que el campo 'id' es un UUID
    protected $keyType = 'string';
    public $incrementing = false;
    protected $primaryKey = 'id_ruta';

    
    // Definir que el id será UUID al crear el cliente
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($ruta) {
            // Si el id no está definido, genera un UUID
            if (!$ruta->id_ruta) {
                $ruta->id_ruta = (string) Guid::uuid4(); // Genera un UUIDv4
            }
        });
    }

    // Definir las columnas que se pueden asignar masivamente
    protected $fillable = [
        'id_ruta', 'id_comessa', 'remitente', 'entrega', 'id_clientes', 'id_user', 'id_encargado', 'id_transporte',
        'descripcion_retiros', 'estado_retiro', 'prioridad', 'hora', 'fecha', 'ruta_maps', 'posicion', 'corriere'
    ];

    // Definir relaciones con otros modelos
    public function cliente()
    {
        return $this->belongsTo(Cliente::class, 'id_clientes', 'id_clientes');
    }
    
    public function encargado()
    {
        return $this->belongsTo(Encargado::class, 'id_encargado', 'id_encargado');
    }
    
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id');
    }
    

    public function transporte()
    {
        return $this->belongsTo(TipoTransporte::class, 'id_transporte', 'id_transporte');
    }
    

    // Relación con Proveedor como remitente
    public function proveedorRemitente()
    {
        return $this->belongsTo(Proveedor::class, 'remitente', 'id_proveedor');
    }

    // Relación con Proveedor como entrega
    public function proveedorEntrega()
    {
        return $this->belongsTo(Proveedor::class, 'entrega', 'id_proveedor');
    }

    // Relación con Proveedor
    public function comessa()
    {
        return $this->belongsTo(Comessa::class, 'id_comessa', 'id_comessa');
    }
    
}

