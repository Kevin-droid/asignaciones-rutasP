<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Ramsey\Uuid\Guid\Guid;
use Ramsey\Uuid\Guid\GuidInterface;

class Encargado extends Model
{
    use HasFactory;

    // Indica que el campo 'id' es un UUID
    protected $keyType = 'string';
    public $incrementing = false;
    protected $primaryKey = 'id_encargado';

     // Relación con Ruta
     public function rutas()
     {
         return $this->hasMany(Ruta::class, 'id_encargado', 'id_encargado');
     }

    // Definir que el id será UUID al crear el cliente
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($encargado) {
            // Si el id no está definido, genera un UUID
            if (!$encargado->id_encargado) {
                $encargado->id_encargado = (string) Guid::uuid4(); // Genera un UUIDv4
            }
        });
    }

    // Campos que se pueden asignar masivamente
    protected $fillable = [
        'id_encargado',
        'nombre_encargado',
        'direccion_clientes',
        'numero_encargado'
        // Agrega los demás campos según la estructura de tu tabla
    ];

    // Si es necesario, define las relaciones, mutadores, etc.
}
