<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Ramsey\Uuid\Guid\Guid;
use Ramsey\Uuid\Guid\GuidInterface;

class Comessa extends Model
{
    use HasFactory;
        
    protected $primaryKey = 'id_comessa';
    

    // Campos que se pueden asignar masivamente
    protected $fillable = [
        'id_comessa',
        'Comessa',
        'id_clientes',
        'descripcion'
        // Agrega los demás campos según la estructura de tu tabla
    ];

    // Si es necesario, define las relaciones, mutadores, etc.
    // Relación con Clientes 
    // Definir relaciones con otros modelos
    public function cliente()
    {
        return $this->belongsTo(Cliente::class, 'id_clientes', 'id_clientes');
    }

      // Relación con Ruta, donde 'remitente' es la clave foránea en la tabla 'rutas'
      public function rutas()
      {
          return $this->hasMany(Ruta::class, 'id_comessa', 'id_comessa');
      }
 
}
