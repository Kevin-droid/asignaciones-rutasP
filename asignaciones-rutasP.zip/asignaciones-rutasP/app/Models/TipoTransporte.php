<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Ramsey\Uuid\Guid\Guid;
use Ramsey\Uuid\Guid\GuidInterface;

class TipoTransporte extends Model
{
    use HasFactory;

    // Indica que el campo 'id' es un UUID
    protected $table = 'tipos_transporte';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $primaryKey = 'id_transporte';

    // Definir que el id será UUID al crear el cliente
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($transporte) {
            // Si el id no está definido, genera un UUID
            if (!$transporte->id_transporte) {
                $transporte->id_transporte = (string) Guid::uuid4(); // Genera un UUIDv4
            }
        });
    }

    // Campos que se pueden asignar masivamente
    protected $fillable = [
        'id_transporte',
        'nombre_transporte'
        // Agrega los demás campos según la estructura de tu tabla
    ];

    // Relación con Ruta
    public function rutas()
    {
        return $this->hasMany(Ruta::class, 'id_transporte', 'id_transporte');
    }
    // Si es necesario, define las relaciones, mutadores, etc.
}
