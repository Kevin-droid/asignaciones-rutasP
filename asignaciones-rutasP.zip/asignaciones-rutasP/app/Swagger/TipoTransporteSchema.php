<?php

// app/Swagger/ClienteSchema.php

namespace App\Swagger;


/**
 * @OA\Schema(
 *     schema="TipoTransporte",
 *     type="object",
 *     required={"nombre_transporte"},
 *     @OA\Property(property="nombre_transporte", type="string")
 * )
 */
 class TipoTransporteSchema
{
    // La clase puede estar vacía, ya que solo contiene las anotaciones de Swagger
}
