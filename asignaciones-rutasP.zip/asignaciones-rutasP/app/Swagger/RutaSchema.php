<?php

namespace App\Swagger;

use OpenApi\Annotations as OA;

/**
 * @OA\Schema(
 *     schema="Ruta",
 *     type="object",
 *     @OA\Property(property="id_ruta", type="string", description="ID único de la ruta"),
 *     @OA\Property(property="id_comessa", type="integer", description="ID de la comessa asociada a la ruta"),
 *     @OA\Property(property="remitente", type="integer", description="ID del proveedor asociado como remitente a la ruta"),
 *     @OA\Property(property="entrega", type="integer", description="ID del proveedor asociado como entrega a la ruta"),
 *     @OA\Property(property="id_clientes", type="string", description="ID del cliente asociado a la ruta"),
 *     @OA\Property(property="id_user", type="integer", description="ID del usuario que gestionó la ruta"),
 *     @OA\Property(property="id_encargado", type="string", description="ID del encargado de la ruta"),
 *     @OA\Property(property="id_transporte", type="string", description="ID del transporte utilizado"),
 *     @OA\Property(property="descripcion_retiros", type="string", description="Descripción de los retiros asociados a la ruta"),
 *     @OA\Property(property="estado_retiro", type="integer", description="Estado del retiro"),
 *     @OA\Property(property="prioridad", type="integer", description="Prioridad de la ruta"),
 *     @OA\Property(property="hora", type="string", description="Orario ritiro"),
 *     @OA\Property(property="fecha", type="string", format="date", description="Fecha asociada a la ruta"),
 *     @OA\Property(property="ruta_maps", type="string", description="URL para visualizar la ruta en Google Maps"),
 *     @OA\Property(property="posicion", type="integer", description="Posición de la ruta - orden"),
 *     @OA\Property(property="created_at", type="string", format="date-time", description="Fecha y hora de creación del registro"),
 *     @OA\Property(property="updated_at", type="string", format="date-time", description="Fecha y hora de la última actualización del registro"),
 *     @OA\Property(property="corriere", type="string", description="Mensajero de la ruta")
 * )
 */
class RutaSchema
{
    // La clase puede estar vacía, ya que solo contiene las anotaciones de Swagger
}
