<?php

// app/Swagger/ClienteSchema.php

namespace App\Swagger;


/**
 * @OA\Schema(
 *     schema="User",
 *     type="object",
 *     @OA\Property(property="id", type="integer"),
 *     @OA\Property(property="name", type="string"),
 *     @OA\Property(property="email", type="string"),
 *     @OA\Property(property="created_at", type="string", format="date-time"),
 *     @OA\Property(property="updated_at", type="string", format="date-time")
 * )
 */
 class UserSchema
{
    // La clase puede estar vacía, ya que solo contiene las anotaciones de Swagger
}
