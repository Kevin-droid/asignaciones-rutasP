<?php

// app/Swagger/ClienteSchema.php

namespace App\Swagger;

/**
 * @OA\Schema(
 *     schema="Cliente",
 *     type="object",
 *     required={"nombre_clientes", "direccion_clientes", "numero_telefonico"},
 *     @OA\Property(property="nombre_clientes", type="string", example="Juan Pérez"),
 *     @OA\Property(property="direccion_clientes", type="string", example="Calle Falsa 123"),
 *     @OA\Property(property="numero_telefonico", type="string", example="555-1234")
 * )
 */
class ClienteSchema
{
    // La clase puede estar vacía, ya que solo contiene las anotaciones de Swagger
}
