<?php

namespace App\Swagger;

// app/Swagger/SwaggerInfo.php

/**
 * @OA\Info(
 *     title="API de Asignaciones de Rutas",
 *     version="1.0.0",
 *     description="Esta API permite gestionar asignaciones y rutas para los clientes.",
 *     termsOfService="https://example.com/terms",
 *     @OA\Contact(
 *         email="support@example.com"
 *     ),
 *     @OA\License(
 *         name="MIT",
 *         url="https://opensource.org/licenses/MIT"
 *     )
 * )
 * 
 * @OA\SecurityScheme(
 *     securityScheme="Bearer",
 *     type="http",
 *     scheme="bearer",
 *     bearerFormat="JWT"
 * )
 */
class SwaggerInfo
{
    // Esta clase está vacía, pero contiene las anotaciones necesarias para Swagger.
}
