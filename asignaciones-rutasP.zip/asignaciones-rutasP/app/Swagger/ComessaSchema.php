<?php

// app/Swagger/ComessaSchema.php

namespace App\Swagger;

/**
 * @OA\Schema(
 *     schema="Comessa",
 *     type="object",
 *     required={"Comessa", "id_clientes", "descripcion"},
 *     @OA\Property(property="Comessa", type="string", example="Juan Pérez"),
 *     @OA\Property(property="id_clientes", type="string", example="Calle Falsa 123"),
 *     @OA\Property(property="descripcion", type="string", example="555-1234")
 * )
 */
class ComessaSchema
{
    // La clase puede estar vacía, ya que solo contiene las anotaciones de Swagger
}
