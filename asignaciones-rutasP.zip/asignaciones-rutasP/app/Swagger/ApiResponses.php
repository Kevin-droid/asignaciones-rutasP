<?php
// app/Swagger/ApiResponses.php

namespace App\Swagger;

/**
 * @OA\Response(
 *     response=200,
 *     description="Operación exitosa",
 *     @OA\JsonContent(ref="#/components/schemas/Cliente")
 * )
 */

/**
 * @OA\Response(
 *     response=400,
 *     description="Error en la solicitud"
 * )
 */

/**
 * @OA\Response(
 *     response=404,
 *     description="No encontrado"
 * )
 */
class ApiResponses
{
    // Esta clase solo se usa para contener las anotaciones.
}
