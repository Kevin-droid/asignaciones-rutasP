<?php

// app/Swagger/EncargadoSchema.php

namespace App\Swagger;

/**
 * @OA\Schema(
 *     schema="Encargado",
 *     type="object",
 *     required={"nombre_encargado", "numero_encargado"},
 *     @OA\Property(property="nombre_encargado", type="string", example="Juan Pérez"),
 *     @OA\Property(property="numero_encargado", type="int", example="120")
 * )
 */
class EncargadoSchema
{
    // La clase puede estar vacía, ya que solo contiene las anotaciones de Swagger
}
