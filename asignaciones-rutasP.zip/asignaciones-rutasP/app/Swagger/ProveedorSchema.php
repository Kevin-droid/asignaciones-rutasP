<?php

// app/Swagger/ProveedorSchema.php

namespace App\Swagger;

/**
 * @OA\Schema(
 *     schema="Proveedor",
 *     type="object",
 *     required={"nombre", "direccion", "telefono"},
 *     @OA\Property(property="nombre", type="string", example="Juan Pérez"),
 *     @OA\Property(property="direccion", type="string", example="Calle Falsa 123"),
 *     @OA\Property(property="telefono", type="string", example="555-1234")
 * )
 */
class ProveedorSchema
{
    // La clase puede estar vacía, ya que solo contiene las anotaciones de Swagger
}
