<?php
// app/Swagger/AuthSchema.php

namespace App\Swagger;

/**
 * @OA\Schema(
 *     schema="Auth",
 *     type="object",
 *     required={"token"},
 *     @OA\Property(property="token", type="string", example="your-jwt-token")
 * )
 */
class AuthSchema
{
    // Esta clase puede estar vacía, pero debe tener las anotaciones necesarias.
}
