<?php

// app/Swagger/Paths.php
namespace App\Swagger;


/**
 * @OA\PathItem(
 *     path="/api/clientes",
 *     @OA\Get(
 *         summary="Obtener todos los clientes",
 *         description="Devuelve una lista de todos los clientes",
 *         @OA\Response(
 *             response=200,
 *             description="Operación exitosa",
 *             @OA\JsonContent(ref="#/components/schemas/Cliente")
 *         ),
 *         @OA\Response(response=400, description="Error en la solicitud")
 *     )
 * )
 */
