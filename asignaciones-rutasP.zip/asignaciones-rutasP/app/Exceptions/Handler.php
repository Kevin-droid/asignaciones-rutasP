<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Auth\AuthenticationException;

class Handler extends ExceptionHandler
{
    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }


    public function render($request, Throwable $exception)
{
    // Maneja las excepciones de autenticación de JWT
    if ($exception instanceof AuthenticationException) {
        return response()->json(['error' => 'Unauthorized'], 401);
    }

    // Maneja errores específicos de JWT
    if ($exception instanceof JWTException) {
        return response()->json(['error' => 'Token is invalid or expired'], 401);
    }

    return parent::render($request, $exception);
    }
}
