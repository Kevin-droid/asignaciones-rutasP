<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Http\Request;

class Authenticate extends Middleware
{
    /**
     * Get the path the user should be redirected to when they are not authenticated.
     */
    protected function redirectTo(Request $request): ?string
    {
        // Si la solicitud es para la API, devolver un error 401 en lugar de redirigir
        if ($request->is('api/*')) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        // Si no es una solicitud de API, redirigir al login (esto es para rutas web)
        return $request->expectsJson() ? null : route('login');
    }
}
