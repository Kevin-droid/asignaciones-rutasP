<?php

namespace App\Http\Controllers;

use App\Models\Comessa;
use Illuminate\Http\Request;

/**
 * @OA\Tag(
 *     name="Comessa",
 *     description="Operaciones relacionadas con comessa"
 * )
 */
class ComessaController extends Controller
{
      /**
     * @OA\Get(
     *     path="/api/comessa",
     *     summary="Obtener todos los comessa",
     *     description="Devuelve una lista de todos los comessa",
     *     tags={"Comessa"},
     *     security={{"Bearer": {}}},
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Comessa"))
     *     )
     * )
     */
    public function index()
    {
        $Comessa = Comessa::all();
        return response()->json($Comessa);
    }


    /**
     * @OA\Post(
     *     path="/api/comessa",
     *     summary="Crear una nueva comessa",
     *     description="Crea un nueva comessa en el sistema",
     *     tags={"Comessa"},
     *     security={{"Bearer": {}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Comessa")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Comessa creado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Comessa")
     *     ),
     *     @OA\Response(response=422, description="Errores de validación")
     * )
     */
    public function store(Request $request)
    {
        try {
            // Validación de los datos del cliente
            $validated = $request->validate([
                'Comessa' => 'required|string|max:255',
                'id_clientes' => 'required|string|max:255',
                'descripcion' => 'required|string|max:255',
            ]);

            // Crear el comessa si la validación pasa
            $comessa = Comessa::create($validated);

            return response()->json([
                'message' => 'Comessa creado exitosamente',
                'cliente' => $comessa
            ], 201);
            
        } catch (\Exception $e) {
            return response()->json([
                'errors' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/comessa/{id}",
     *     summary="Obtener una comessa por su ID",
     *     description="Devuelve los detalles de un comessa específico",
     *     tags={"Comessa"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del comessa",
     *         required=true,
     *         @OA\Schema(type="int")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(ref="#/components/schemas/Comessa")
     *     ),
     *     @OA\Response(response=404, description="Comessa no encontrado")
     * )
     */
    public function show($id)
    {
        $comessa = Comessa::find($id);
        if (!$comessa) {
            return response()->json(['error' => 'Comessa no encontrado'], 404);
        }

        return response()->json($comessa);
    }

    /**
     * @OA\Put(
     *     path="/api/comessa/{id}",
     *     summary="Actualizar un comessa",
     *     description="Actualiza la información de un comessa específico",
     *     tags={"Comessa"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del comessa",
     *         required=true,
     *         @OA\Schema(type="int")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Comessa")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Comessa actualizado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Comessa")
     *     ),
     *     @OA\Response(response=404, description="Comessa no encontrado")
     * )
     */
    public function update(Request $request, $id)
    {
        $comessa = Comessa::find($id);
        if (!$comessa) {
            return response()->json(['error' => 'Comessa no encontrado'], 404);
        }

        $validated = $request->validate([
            'Comessa' => 'required|string|max:255',
            'id_clientes' => 'required|string|max:255 ',
            'descripcion' => 'required|string|max:255',
        ]);

        $comessa->update($validated);
        return response()->json($comessa);
    }

    /**
     * @OA\Delete(
     *     path="/api/comessa/{id}",
     *     summary="Eliminar un comessa",
     *     description="Elimina un comessa específico",
     *     tags={"Comessa"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del comessa",
     *         required=true,
     *         @OA\Schema(type="int")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Comessa eliminado exitosamente"
     *     ),
     *     @OA\Response(response=404, description="Comessa no encontrado")
     * )
     */
    public function destroy($id)
    {
        $comessa = Comessa::find($id);
        if (!$comessa) {
            return response()->json(['error' => 'Comessa no encontrado'], 404);
        }

        $comessa->delete();
        return response()->json(['message' => 'Comessa eliminado exitosamente']);
    }
}
