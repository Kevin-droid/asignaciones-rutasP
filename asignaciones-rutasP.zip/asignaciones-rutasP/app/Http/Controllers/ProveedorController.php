<?php

namespace App\Http\Controllers;

use App\Models\Proveedor;
use Illuminate\Http\Request;

/**
 * @OA\Tag(
 *     name="Proveedores",
 *     description="Operaciones relacionadas con Proveedores"
 * )
 */
class ProveedorController extends Controller
{
      /**
     * @OA\Get(
     *     path="/api/proveedores",
     *     summary="Obtener todos los Proveedores",
     *     description="Devuelve una lista de todos los Proveedores",
     *     tags={"Proveedores"},
     *     security={{"Bearer": {}}},
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Proveedor"))
     *     )
     * )
     */
    public function index()
    {
        $Proveedores = Proveedor::all();
        return response()->json($Proveedores);
    }


    /**
     * @OA\Post(
     *     path="/api/proveedores",
     *     summary="Crear un nuevo Proveedor",
     *     description="Crea un nuevo Proveedor en el sistema",
     *     tags={"Proveedores"},
     *     security={{"Bearer": {}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Proveedor")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Proveedor creado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Proveedor")
     *     ),
     *     @OA\Response(response=422, description="Errores de validación")
     * )
     */
    public function store(Request $request)
    {
        try {
            // Validación de los datos del Proveedor
            $validated = $request->validate([
                'nombre' => 'required|string|max:100',
                'direccion' => 'required|string|max:255',
                'telefono' => 'required|string|max:15',
            ]);

            // Crear el Proveedor si la validación pasa
            $proveedor = Proveedor::create($validated);

            return response()->json([
                'message' => 'Proveedor creado exitosamente',
                'Proveedor' => $proveedor
            ], 201);
            
        } catch (\Exception $e) {
            return response()->json([
                'errors' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/proveedores/{id}",
     *     summary="Obtener un proveedor por su ID",
     *     description="Devuelve los detalles de un proveedor específico",
     *     tags={"Proveedores"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del Proveedor",
     *         required=true,
     *         @OA\Schema(type="int")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(ref="#/components/schemas/Proveedor")
     *     ),
     *     @OA\Response(response=404, description="Proveedor no encontrado")
     * )
     */
    public function show($id)
    {
        $proveedor = Proveedor::find($id);
        if (!$proveedor) {
            return response()->json(['error' => 'Proveedor no encontrado'], 404);
        }

        return response()->json($Proveedor);
    }

    /**
     * @OA\Put(
     *     path="/api/proveedores/{id}",
     *     summary="Actualizar un Proveedor",
     *     description="Actualiza la información de un proveedor específico",
     *     tags={"Proveedores"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del Proveedor",
     *         required=true,
     *         @OA\Schema(type="int")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Proveedor")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Proveedor actualizado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Proveedor")
     *     ),
     *     @OA\Response(response=404, description="Proveedor no encontrado")
     * )
     */
    public function update(Request $request, $id)
    {
        $Proveedor = Proveedor::find($id);
        if (!$Proveedor) {
            return response()->json(['error' => 'Proveedor no encontrado'], 404);
        }

        $validated = $request->validate([
            'nombre' => 'required|string|max:100',
            'direccion' => 'required|string|max:255',
            'telefono' => 'required|string|max:15',
        ]);

        $Proveedor->update($validated);
        return response()->json($Proveedor);
    }

    /**
     * @OA\Delete(
     *     path="/api/proveedores/{id}",
     *     summary="Eliminar un Proveedor",
     *     description="Elimina un Proveedor específico",
     *     tags={"Proveedores"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del Proveedor",
     *         required=true,
     *         @OA\Schema(type="int")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Proveedor eliminado exitosamente"
     *     ),
     *     @OA\Response(response=404, description="Proveedor no encontrado")
     * )
     */
    public function destroy($id)
    {
        $proveedor = Proveedor::find($id);
        if (!$proveedor) {
            return response()->json(['error' => 'Proveedor no encontrado'], 404);
        }

        $proveedor->delete();
        return response()->json(['message' => 'Proveedor eliminado exitosamente']);
    }
}
