<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Encargado;

/**
 * @OA\Tag(
 *     name="Encargados",
 *     description="Operaciones relacionadas con encargados"
 * )
 */
class EncargadoController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/encargados",
     *     summary="Obtener todos los encargados",
     *     description="Devuelve una lista de todos los encargados",
     *     tags={"Encargados"},
     *     security={{"Bearer": {}}},
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Encargado"))
     *     ),
     *     @OA\Response(response=401, description="No autorizado")
     * )
     */
    public function index()
    {
        $encargados = Encargado::all();
        return response()->json($encargados);
    }

    /**
     * @OA\Post(
     *     path="/api/encargados",
     *     summary="Crear un nuevo encargado",
     *     description="Crea un nuevo encargado en el sistema",
     *     tags={"Encargados"},
     *     security={{"Bearer": {}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Encargado")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Encargado creado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Encargado")
     *     ),
     *     @OA\Response(response=422, description="Errores de validación")
     * )
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre_encargado' => 'required|string|max:255',
            'numero_encargado' => 'required|integer'
        ]);

        $encargado = Encargado::create($validated);

        return response()->json([
            'message' => 'Encargado creado exitosamente',
            'encargado' => $encargado
        ], 201);
    }

    /**
     * @OA\Get(
     *     path="/api/encargados/{id}",
     *     summary="Obtener un encargado por su ID",
     *     description="Devuelve los detalles de un encargado específico",
     *     tags={"Encargados"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del encargado",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(ref="#/components/schemas/Encargado")
     *     ),
     *     @OA\Response(response=404, description="Encargado no encontrado")
     * )
     */
    public function show($id)
    {
        $encargado = Encargado::find($id);
        if (!$encargado) {
            return response()->json(['error' => 'Encargado no encontrado'], 404);
        }

        return response()->json($encargado);
    }

    /**
     * @OA\Put(
     *     path="/api/encargados/{id}",
     *     summary="Actualizar un encargado",
     *     description="Actualiza la información de un encargado específico",
     *     tags={"Encargados"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del encargado",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Encargado")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Encargado actualizado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Encargado")
     *     ),
     *     @OA\Response(response=404, description="Encargado no encontrado")
     * )
     */
    public function update(Request $request, $id)
    {
        $encargado = Encargado::find($id);
        if (!$encargado) {
            return response()->json(['error' => 'Encargado no encontrado'], 404);
        }

        $validated = $request->validate([
            'nombre_encargado' => 'required|string|max:255',
            'numero_encargado' => 'required|integer'
        ]);

        $encargado->update($validated);

        return response()->json($encargado);
    }

    /**
     * @OA\Delete(
     *     path="/api/encargados/{id}",
     *     summary="Eliminar un encargado",
     *     description="Elimina un encargado específico",
     *     tags={"Encargados"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del encargado",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Encargado eliminado exitosamente"
     *     ),
     *     @OA\Response(response=404, description="Encargado no encontrado")
     * )
     */
    public function destroy($id)
    {
        $encargado = Encargado::find($id);
        if (!$encargado) {
            return response()->json(['error' => 'Encargado no encontrado'], 404);
        }

        $encargado->delete();

        return response()->json(['message' => 'Encargado eliminado exitosamente']);
    }
}
