<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TipoTransporte;

/**
 * @OA\Tag(
 *     name="Tipos de Transporte",
 *     description="Operaciones relacionadas con los tipos de transporte"
 * )
 */
class TipoTransporteController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/tipos-transporte",
     *     summary="Obtener todos los tipos de transporte",
     *     description="Devuelve una lista de todos los tipos de transporte",
     *     tags={"Tipos de Transporte"},
     *     security={{"Bearer": {}}},
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/TipoTransporte"))
     *     ),
     *     @OA\Response(response=401, description="No autorizado")
     * )
     */
    public function index()
    {
        $tiposTransporte = TipoTransporte::all();
        return response()->json($tiposTransporte);
    }

    /**
     * @OA\Post(
     *     path="/api/tipos-transporte",
     *     summary="Crear un nuevo tipo de transporte",
     *     description="Crea un nuevo tipo de transporte en el sistema",
     *     tags={"Tipos de Transporte"},
     *     security={{"Bearer": {}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/TipoTransporte")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Tipo de transporte creado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/TipoTransporte")
     *     ),
     *     @OA\Response(response=422, description="Errores de validación")
     * )
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre_transporte' => 'required|string|max:255'
        ]);

        $tipoTransporte = TipoTransporte::create($validated);

        return response()->json([
            'message' => 'Tipo de transporte creado exitosamente',
            'tipo_transporte' => $tipoTransporte
        ], 201);
    }

    /**
     * @OA\Get(
     *     path="/api/tipos-transporte/{id}",
     *     summary="Obtener un tipo de transporte por su ID",
     *     description="Devuelve los detalles de un tipo de transporte específico",
     *     tags={"Tipos de Transporte"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del tipo de transporte",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(ref="#/components/schemas/TipoTransporte")
     *     ),
     *     @OA\Response(response=404, description="Tipo de transporte no encontrado")
     * )
     */
    public function show($id)
    {
        $tipoTransporte = TipoTransporte::find($id);
        if (!$tipoTransporte) {
            return response()->json(['error' => 'Tipo de transporte no encontrado'], 404);
        }

        return response()->json($tipoTransporte);
    }

    /**
     * @OA\Put(
     *     path="/api/tipos-transporte/{id}",
     *     summary="Actualizar un tipo de transporte",
     *     description="Actualiza la información de un tipo de transporte específico",
     *     tags={"Tipos de Transporte"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del tipo de transporte",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/TipoTransporte")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Tipo de transporte actualizado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/TipoTransporte")
     *     ),
     *     @OA\Response(response=404, description="Tipo de transporte no encontrado")
     * )
     */
    public function update(Request $request, $id)
    {
        $tipoTransporte = TipoTransporte::find($id);
        if (!$tipoTransporte) {
            return response()->json(['error' => 'Tipo de transporte no encontrado'], 404);
        }

        $validated = $request->validate([
            'nombre_transporte' => 'required|string|max:255'
        ]);

        $tipoTransporte->update($validated);

        return response()->json($tipoTransporte);
    }

    /**
     * @OA\Delete(
     *     path="/api/tipos-transporte/{id}",
     *     summary="Eliminar un tipo de transporte",
     *     description="Elimina un tipo de transporte específico",
     *     tags={"Tipos de Transporte"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del tipo de transporte",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Tipo de transporte eliminado exitosamente"
     *     ),
     *     @OA\Response(response=404, description="Tipo de transporte no encontrado")
     * )
     */
    public function destroy($id)
    {
        $tipoTransporte = TipoTransporte::find($id);
        if (!$tipoTransporte) {
            return response()->json(['error' => 'Tipo de transporte no encontrado'], 404);
        }

        $tipoTransporte->delete();

        return response()->json(['message' => 'Tipo de transporte eliminado exitosamente']);
    }
}
