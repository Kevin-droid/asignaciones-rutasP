<?php

namespace App\Http\Controllers;

use App\Models\Ruta;
use Illuminate\Http\Request;
use App\Http\Resources\RutaResource;


/**
 * @OA\Tag(
 *     name="Rutas",
 *     description="Operaciones relacionadas con las rutas"
 * )
 */
class RutaController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/rutas",
     *     tags={"Rutas"},
     *     security={{"Bearer": {}}},
     *     summary="Obtener todas las rutas",
     *     description="Devuelve todas las rutas",
     *     @OA\Response(
     *         response=200,
     *         description="Lista de rutas",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Ruta"))
     *     )
     * )
     */
    public function index()
    {
        // Utilizando `with` para cargar las relaciones
        $rutas = Ruta::with(['user', 'encargado', 'transporte'])->get();
        
        return RutaResource::collection($rutas);
    }

    /**
     * @OA\Get(
     *     path="/api/rutas/{id}",
     *     tags={"Rutas"},
     *     security={{"Bearer": {}}},
     *     summary="Obtener una ruta por ID",
     *     description="Devuelve una ruta específica",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="ID de la ruta",
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Ruta encontrada",
     *         @OA\JsonContent(ref="#/components/schemas/Ruta")
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Ruta no encontrada"
     *     )
     * )
     */
    public function show($id)
    {
        // Cargar las relaciones cuando mostramos una ruta específica
        $ruta = Ruta::with(['user', 'encargado', 'transporte'])->findOrFail($id);
        
        return new RutaResource($ruta);
    }

    /**
     * @OA\Post(
     *     path="/api/rutas",
     *     tags={"Rutas"},
     *     security={{"Bearer": {}}},
     *     summary="Crear una nueva ruta",
     *     description="Crea una nueva ruta en el sistema",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Ruta")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Ruta creada",
     *         @OA\JsonContent(ref="#/components/schemas/Ruta")
     *     )
     * )
     */
    public function store(Request $request)
    {
        // Asegúrate de que todos los campos sean parte de los datos recibidos
        $validated = $request->validate([
            'id_comessa' => 'required|string',
            'remitente' => 'required|string',
            'entrega' => 'required|string',
            'id_clientes' => 'required|string',
            'id_user' => 'nullable|integer',
            'id_encargado' => 'required|string',
            'id_transporte' => 'required|string',
            'descripcion_retiros' => 'nullable|string',
            'estado_retiro' => 'required|integer',
            'prioridad' => 'required|integer',
            'hora' => 'required|string',
            'fecha' => 'required|date',
            'ruta_maps' => 'nullable|string',
            'posicion' => 'nullable|integer'
        ]);

        // Crear la nueva ruta usando los datos validados
        $ruta = Ruta::create($validated);

        // Devolver la nueva ruta en formato JSON usando un recurso
        return new RutaResource($ruta);
    }

    /**
     * @OA\Put(
     *     path="/api/rutas/{id}",
     *     summary="Actualizar una ruta",
     *     description="Actualiza la información de una ruta",
     *     tags={"Rutas"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID de la ruta",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Ruta")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Ruta actualizado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Ruta")
     *     ),
     *     @OA\Response(response=404, description="Ruta no encontrada")
     * )
     */
    public function update(Request $request, $id)
    {
        \Log::info('Datos de la solicitud de actualización:', $request->all());
        
        // Validar los datos de la solicitud
        $validated = $request->validate([
            'id_comessa' => 'required|integer', 
            'remitente' => 'required|string',
            'entrega' => 'required|string',
            'id_clientes' => 'required|string',
            'id_user' => 'nullable|integer',
            'id_encargado' => 'required|string',
            'id_transporte' => 'required|string',
            'descripcion_retiros' => 'nullable|string',
            'estado_retiro' => 'required|integer',
            'prioridad' => 'required|integer',
            'hora' => 'required|string',
            'fecha' => 'required|date',
            'ruta_maps' => 'nullable|string',
            'posicion' => 'nullable|integer',
            'corriere' => 'nullable|string'
        ]);
        
        // Buscar la ruta por id
        $ruta = Ruta::findOrFail($id);
        
        // Actualizar la ruta
        $ruta->update($validated);
        
        return response()->json($ruta, 200);
    }
    
}
