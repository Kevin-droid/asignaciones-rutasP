<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;

/**
 * @OA\Tag(
 *     name="Clientes",
 *     description="Operaciones relacionadas con clientes"
 * )
 */
class ClienteController extends Controller
{
      /**
     * @OA\Get(
     *     path="/api/clientes",
     *     summary="Obtener todos los clientes",
     *     description="Devuelve una lista de todos los clientes",
     *     tags={"Clientes"},
     *     security={{"Bearer": {}}},
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Cliente"))
     *     )
     * )
     */
    public function index()
    {
        $clientes = Cliente::all();
        return response()->json($clientes);
    }


    /**
     * @OA\Post(
     *     path="/api/clientes",
     *     summary="Crear un nuevo cliente",
     *     description="Crea un nuevo cliente en el sistema",
     *     tags={"Clientes"},
     *     security={{"Bearer": {}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Cliente")
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Cliente creado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Cliente")
     *     ),
     *     @OA\Response(response=422, description="Errores de validación")
     * )
     */
    public function store(Request $request)
    {
        try {
            // Validación de los datos del cliente
            $validated = $request->validate([
                'nombre_clientes' => 'required|string|max:255',
                'direccion_clientes' => 'required|string|unique:clientes',
                'numero_telefonico' => 'required|string|max:15',
            ]);

            // Crear el cliente si la validación pasa
            $cliente = Cliente::create($validated);

            return response()->json([
                'message' => 'Cliente creado exitosamente',
                'cliente' => $cliente
            ], 201);
            
        } catch (\Exception $e) {
            return response()->json([
                'errors' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/clientes/{id}",
     *     summary="Obtener un cliente por su ID",
     *     description="Devuelve los detalles de un cliente específico",
     *     tags={"Clientes"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del cliente",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Operación exitosa",
     *         @OA\JsonContent(ref="#/components/schemas/Cliente")
     *     ),
     *     @OA\Response(response=404, description="Cliente no encontrado")
     * )
     */
    public function show($id)
    {
        $cliente = Cliente::find($id);
        if (!$cliente) {
            return response()->json(['error' => 'Cliente no encontrado'], 404);
        }

        return response()->json($cliente);
    }

    /**
     * @OA\Put(
     *     path="/api/clientes/{id}",
     *     summary="Actualizar un cliente",
     *     description="Actualiza la información de un cliente específico",
     *     tags={"Clientes"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del cliente",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(ref="#/components/schemas/Cliente")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Cliente actualizado exitosamente",
     *         @OA\JsonContent(ref="#/components/schemas/Cliente")
     *     ),
     *     @OA\Response(response=404, description="Cliente no encontrado")
     * )
     */
    public function update(Request $request, $id)
    {
        $cliente = Cliente::find($id);
        if (!$cliente) {
            return response()->json(['error' => 'Cliente no encontrado'], 404);
        }

        $validated = $request->validate([
            'nombre_clientes' => 'required|string|max:255',
            'direccion_clientes' => 'required|string|unique:clientes,direccion_clientes,' . $cliente->id_clientes . ',id_clientes',
            'numero_telefonico' => 'required|string|max:15',
        ]);

        $cliente->update($validated);
        return response()->json($cliente);
    }

    /**
     * @OA\Delete(
     *     path="/api/clientes/{id}",
     *     summary="Eliminar un cliente",
     *     description="Elimina un cliente específico",
     *     tags={"Clientes"},
     *     security={{"Bearer": {}}},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="ID del cliente",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Cliente eliminado exitosamente"
     *     ),
     *     @OA\Response(response=404, description="Cliente no encontrado")
     * )
     */
    public function destroy($id)
    {
        $cliente = Cliente::find($id);
        if (!$cliente) {
            return response()->json(['error' => 'Cliente no encontrado'], 404);
        }

        $cliente->delete();
        return response()->json(['message' => 'Cliente eliminado exitosamente']);
    }
}
