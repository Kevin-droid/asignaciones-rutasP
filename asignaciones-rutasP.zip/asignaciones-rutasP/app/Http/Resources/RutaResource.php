<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class RutaResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id_ruta' => $this->id_ruta,
            'id_comessa' => $this->id_comessa ? $this->Comessa->Comessa : null, 
            'remitente' => $this->remitente, 
            'entrega' => $this->entrega, 
            'id_clientes' => $this->id_clientes,
            'nombre_cliente' => $this->cliente ? $this->cliente->nombre_clientes : null, // Nombre del cliente relacionado
            'id_user' => $this->id_user,
            'user_name' => $this->user ? $this->user->name : null,  // Nombre del usuario relacionado
            'id_encargado' => $this->id_encargado,
            'nombre_encargado' => $this->encargado ? $this->encargado->nombre_encargado : null,  // Nombre del encargado relacionado
            'id_transporte' => $this->id_transporte,
            'nombre_transporte' => $this->transporte ? $this->transporte->nombre_transporte : null,  // Nombre del transporte relacionado
            'descripcion_retiros' => $this->descripcion_retiros,
            'estado_retiro' => $this->estado_retiro,
            'prioridad' => $this->prioridad,
            'hora' => $this->hora,  
            'fecha' => $this->fecha,
            'ruta_maps' => $this->ruta_maps,
            'posicion' => $this->posicion, 
            'created_at' => $this->created_at,  
            'updated_at' => $this->updated_at,  
            'corriere' => $this->corriere, 
        ];
    }
}

